package com.example.msrrunner.model;

public class ApplicationDbDetail {
    private int msrslno;
    private String dbserverIp;
    private String dbPort;
    private String dbName;
    private String dbUsername;
    private String msrstatename;
    private String msrstate_category;
    private String msrstate_subcategory;

    public int getmsrslno() {
        return msrslno;
    }

    public void setmsrslno(int msrslno) {
        this.msrslno = msrslno;
    }

    public String getdbServerIp() {
        return dbserverIp;
    }

    public void setdbServerIp(String dbserverIp) {
        this.dbserverIp = dbserverIp;
    }

    public String getdbPort() {
        return dbPort;
    }

    public void setdbPort(String dbPort) {
        this.dbPort = dbPort;
    }

    public String getdbName() {
        return dbName;
    }

    public void setdbName(String dbName) {
        this.dbName = dbName;
    }

    public String getdbUsername() {
        return dbUsername;
    }

    public void setdbUsername(String dbUsername) {
        this.dbUsername = dbUsername;
    }

    public String getmsrstatename() {
        return msrstatename;
    }

    public void setmsrstatename(String msrstatename) {
        this.msrstatename = msrstatename;
    }
    
    public String getmsrstate_category() {
        return msrstate_category;
    }

    public void setmsrstate_category(String msrstate_category) {
        this.msrstate_category = msrstate_category;
    }
    public String getmsrstate_subcategory() {
        return msrstate_subcategory;
    }

    public void setmsrstate_subcategory(String msrstate_subcategory) {
        this.msrstate_subcategory = msrstate_subcategory;
    }
    /*public void setdbPort(String dbPort) {
        throw new UnsupportedOperationException("Unimplemented method 'setdbPort'");
    }*/
}