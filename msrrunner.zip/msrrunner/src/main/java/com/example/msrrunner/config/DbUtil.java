package com.example.msrrunner.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {

    // For dynamic DBs like demoproc (used to read view)
    public static Connection getConnection(String host, String port, String dbName, String username, String password) throws SQLException {
        String url = "jdbc:postgresql://192.168.1.6:5433/demoproc";
        return DriverManager.getConnection(url, username, password);
    }

    // For local msr DB where the final insert happens
    public static Connection getLocalConnection() throws SQLException {
        String url = "jdbc:postgresql://192.168.1.6:5433/msr"; 
        String user = "postgres";
        String password = "trust";
        return DriverManager.getConnection(url, user, password);
    }
}
