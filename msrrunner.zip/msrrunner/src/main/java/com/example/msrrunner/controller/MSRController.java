package com.example.msrrunner.controller;

import com.example.msrrunner.model.ApplicationDbDetail;
import com.example.msrrunner.repository.ApplicationDbDetailsRepository;
import com.example.msrrunner.service.ReportService;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.util.List;

@RestController
@RequestMapping("/api")
public class MSRController {

    private final ReportService reportService = new ReportService();
    private final ApplicationDbDetailsRepository dbDetailsRepository = new ApplicationDbDetailsRepository();

    @PostMapping("/generate-msr")
    public ResponseEntity<InputStreamResource> generateMSR() throws IOException {
        // 1. Fetch DB configs from repository
        List<ApplicationDbDetail> dbDetails = dbDetailsRepository.findAll();

        // 2. Generate Excel
        reportService.process(dbDetails);

        // 3. Send Excel file to frontend
        File file = new File("all_states_report.xlsx");
        InputStreamResource resource = new InputStreamResource(new FileInputStream(file));

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=GePNIC_MSR_PreviousMonth.xlsx")
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .contentLength(file.length())
                .body(resource);
    }
}
