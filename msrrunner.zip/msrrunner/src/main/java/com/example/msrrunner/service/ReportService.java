package com.example.msrrunner.service;

import com.example.msrrunner.config.DbUtil;
import com.example.msrrunner.model.ApplicationDbDetail;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.*;

import java.util.Locale;

public class ReportService {

    private static final String EXCEL_FILE = "all_states_report.xlsx";

    public void process(List<ApplicationDbDetail> dbDetails) {
        Map<String, List<List<String>>> categoryDataMap = new LinkedHashMap<>();

        // Generate dynamic months
        LocalDate now = LocalDate.now();
        LocalDate currentMonthDate = now.minusMonths(1);
        LocalDate previousMonthDate = now.minusMonths(2);

        String currMonthYear = currentMonthDate.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " " + currentMonthDate.getYear();
        String prevMonthYear = previousMonthDate.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " " + previousMonthDate.getYear();
        String uptoMonth = "Upto " + currentMonthDate.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " " + currentMonthDate.getYear();

        List<String> headers = Arrays.asList(
                "Sl No", "State/Organization",
                currMonthYear + " (No.)", currMonthYear + " (Value)",
                prevMonthYear + " (No.)", prevMonthYear + " (Value)",
                uptoMonth + " (No.)", uptoMonth + " (Value)",
                "Cumulative (No.)", "Cumulative (Value)",
                "Bid Awards (No.)", "Bid Awards (Value)"
        );

        try (Connection localConn = DbUtil.getLocalConnection()) {
            Statement localStmt = localConn.createStatement();
            localStmt.executeUpdate("DELETE FROM msr_tender_statistical");
            localStmt.executeUpdate("DELETE FROM msr_report");

            for (ApplicationDbDetail detail : dbDetails) {
                try (Connection conn = DbUtil.getConnection(
                        detail.getdbServerIp(),
                        detail.getdbPort(),
                        detail.getdbName(),
                        detail.getdbUsername(),
                        "trust"
                )) {
                    Statement stmt = conn.createStatement();
                    stmt.executeUpdate("CREATE OR REPLACE VIEW gep_view_msr_details AS " +
                            "SELECT cm.curr_month_tends, cm.curr_month_values, " +
                            "pm.prev_month_tends, pm.prev_month_values, " +
                            "fy.curr_fin_yr_tends, fy.curr_fin_yr_values, " +
                            "fyaoc.curr_fin_yr_aoc, fyaoc.curr_fin_yr_aoc_values, now() AS executed_time FROM " +
                            "(SELECT COUNT(*) AS curr_month_tends, SUM(t1.tendervalue)/10000000 AS curr_month_values FROM gep_tender_work_items t1 " +
                            "JOIN gep_tender_basic_details t2 ON t1.tenderbasicid = t2.id " +
                            "JOIN gep_tender_critical_dates t3 ON t1.id = t3.workitemid " +
                            "JOIN gep_orgchain_master om ON om.id = t2.actualorgid WHERE t1.ispublished = true " +
                            "AND om.secratariatdepartmentid IN (2,4,5,8,9,10) " +
                            "AND DATE_PART('month', t3.publishdate) = DATE_PART('month', NOW() - INTERVAL '1 month') " +
                            "AND DATE_PART('year', t3.publishdate) = DATE_PART('year', NOW() - INTERVAL '1 month')) cm, " +
                            "(SELECT COUNT(*) AS prev_month_tends, SUM(t1.tendervalue)/10000000 AS prev_month_values FROM gep_tender_work_items t1 " +
                            "JOIN gep_tender_basic_details t2 ON t1.tenderbasicid = t2.id " +
                            "JOIN gep_tender_critical_dates t3 ON t1.id = t3.workitemid " +
                            "JOIN gep_orgchain_master om ON om.id = t2.actualorgid WHERE t1.ispublished = true " +
                            "AND om.secratariatdepartmentid IN (2,4,5,8,9,10) " +
                            "AND DATE_PART('month', t3.publishdate) = DATE_PART('month', NOW() - INTERVAL '2 month') " +
                            "AND DATE_PART('year', t3.publishdate) = DATE_PART('year', NOW() - INTERVAL '2 month')) pm, " +
                            "(SELECT COUNT(*) AS curr_fin_yr_tends, SUM(t1.tendervalue)/10000000 AS curr_fin_yr_values FROM gep_tender_work_items t1 " +
                            "JOIN gep_tender_basic_details t2 ON t1.tenderbasicid = t2.id " +
                            "JOIN gep_tender_critical_dates t3 ON t1.id = t3.workitemid " +
                            "JOIN gep_orgchain_master om ON om.id = t2.actualorgid WHERE t1.ispublished = true " +
                            "AND DATE(t3.publishdate) >= DATE(DATE_PART('year', NOW() - INTERVAL '4 months') || '-04-01') " +
                            "AND DATE(t3.publishdate) < DATE_TRUNC('month', CURRENT_DATE)) fy, " +
                            "(SELECT COUNT(*) AS curr_fin_yr_aoc, SUM(t3.contractvalue)/10000000 AS curr_fin_yr_aoc_values FROM gep_tender_work_items t1 " +
                            "JOIN gep_tender_basic_details t2 ON t1.tenderbasicid = t2.id " +
                            "JOIN gep_bid_aoc t3 ON t1.id = t3.workitemid " +
                            "JOIN gep_orgchain_master om ON om.id = t2.actualorgid WHERE t1.ispublished = true " +
                            "AND t1.tenderstatus = 'Expired' AND om.secratariatdepartmentid IN (2,4,5,8,9,10) " +
                            "AND DATE(t3.contractdate) >= DATE(DATE_PART('year', NOW() - INTERVAL '4 months') || '-04-01') " +
                            "AND DATE(t3.contractdate) < DATE_TRUNC('month', CURRENT_DATE)) fyaoc");

                    ResultSet rs = stmt.executeQuery("SELECT * FROM gep_view_msr_details");
                    if (rs.next()) {
                        String cumulativeTender = "0";
                        String cumulativeValue = "0";

                        PreparedStatement cumStmt = localConn.prepareStatement(
                                "SELECT cum_no_of_tenders, cum_value_of_tenders FROM msr_cumulative_tenders WHERE instance_name = ?");
                        cumStmt.setString(1, detail.getmsrstatename());
                        ResultSet cumRs = cumStmt.executeQuery();
                        if (cumRs.next()) {
                            cumulativeTender = cumRs.getString("cum_no_of_tenders");
                            cumulativeValue = cumRs.getString("cum_value_of_tenders");
                        }

                        PreparedStatement insertStat = localConn.prepareStatement(
                                "INSERT INTO msr_tender_statistical (" +
                                        "instance_name, instance_category, curr_month_no_of_tenders, curr_month_value_of_tenders, " +
                                        "previous_month_no_of_tenders, previous_month_value_of_tenders, " +
                                        "upto_month_no_of_tenders, upto_month_value_of_tenders, " +
                                        "bidawards_no_of_tenders, bidawards_value_of_tenders, msrslno) " +
                                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                        );
                        insertStat.setString(1, detail.getmsrstatename());
                        insertStat.setString(2, detail.getmsrstate_category());
                        insertStat.setString(3, rs.getString("curr_month_tends"));
                        insertStat.setString(4, rs.getString("curr_month_values"));
                        insertStat.setString(5, rs.getString("prev_month_tends"));
                        insertStat.setString(6, rs.getString("prev_month_values"));
                        insertStat.setString(7, rs.getString("curr_fin_yr_tends"));
                        insertStat.setString(8, rs.getString("curr_fin_yr_values"));
                        insertStat.setString(9, rs.getString("curr_fin_yr_aoc"));
                        insertStat.setString(10, rs.getString("curr_fin_yr_aoc_values"));
                        insertStat.setInt(11, detail.getmsrslno());
                        insertStat.executeUpdate();

                        PreparedStatement insertReport = localConn.prepareStatement(
                                "INSERT INTO msr_report (" +
                                        "slno, state_organization, instance_category, curr_month_no_of_tenders, curr_month_value_of_tenders, " +
                                        "prev_month_no_of_tenders, prev_month_value_of_tenders, upto_month_no_of_tenders, upto_month_value_of_tenders, " +
                                        "cum_no_of_tenders, cum_value_of_tenders, bidawards_no_of_tenders, bidawards_value_of_tenders" +
                                        ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                        );
                        insertReport.setInt(1, detail.getmsrslno());
                        insertReport.setString(2, detail.getmsrstatename());
                        insertReport.setString(3, detail.getmsrstate_category());
                        insertReport.setString(4, rs.getString("curr_month_tends"));
                        insertReport.setString(5, rs.getString("curr_month_values"));
                        insertReport.setString(6, rs.getString("prev_month_tends"));
                        insertReport.setString(7, rs.getString("prev_month_values"));
                        insertReport.setString(8, rs.getString("curr_fin_yr_tends"));
                        insertReport.setString(9, rs.getString("curr_fin_yr_values"));
                        insertReport.setString(10, cumulativeTender);
                        insertReport.setString(11, cumulativeValue);
                        insertReport.setString(12, rs.getString("curr_fin_yr_aoc"));
                        insertReport.setString(13, rs.getString("curr_fin_yr_aoc_values"));
                        insertReport.executeUpdate();

                        List<String> row = Arrays.asList(
                                String.valueOf(detail.getmsrslno()),
                                detail.getmsrstatename(),
                                rs.getString("curr_month_tends"),
                                rs.getString("curr_month_values"),
                                rs.getString("prev_month_tends"),
                                rs.getString("prev_month_values"),
                                rs.getString("curr_fin_yr_tends"),
                                rs.getString("curr_fin_yr_values"),
                                cumulativeTender,
                                cumulativeValue,
                                rs.getString("curr_fin_yr_aoc"),
                                rs.getString("curr_fin_yr_aoc_values")
                        );

                        categoryDataMap.computeIfAbsent(detail.getmsrstate_category(), k -> new ArrayList<>()).add(row);
                    }
                }
            }

            writeToExcel(headers, categoryDataMap, currMonthYear);
            System.out.println("✅ Excel file written to: " + EXCEL_FILE);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void writeToExcel(List<String> headers, Map<String, List<List<String>>> dataMap, String currMonthYear) throws Exception {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("all_states_report");

        CellStyle headerStyle = createHeaderStyle(workbook);
        CellStyle borderStyle = createBorderedStyle(workbook);
        CellStyle boldStyle = createBoldStyle(workbook);
        CellStyle categoryStyle = createCategoryStyle(workbook);

        int rowIndex = 0;

        Row mainHeader = sheet.createRow(rowIndex++);
        Cell cell = mainHeader.createCell(0);
        cell.setCellValue("NIC eProcurement (GePNIC) Tender Statistics for the Month of " + currMonthYear);
        CellStyle mainHeaderStyle = workbook.createCellStyle();
        mainHeaderStyle.cloneStyleFrom(boldStyle);
        mainHeaderStyle.setFillForegroundColor(IndexedColors.GREEN.getIndex());
        mainHeaderStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        cell.setCellStyle(mainHeaderStyle);
        sheet.addMergedRegion(new org.apache.poi.ss.util.CellRangeAddress(0, 0, 0, headers.size() - 1));

        Row headerRow = sheet.createRow(rowIndex++);
        for (int i = 0; i < headers.size(); i++) {
            Cell hCell = headerRow.createCell(i);
            hCell.setCellValue(headers.get(i));
            hCell.setCellStyle(headerStyle);
        }

        for (Map.Entry<String, List<List<String>>> entry : dataMap.entrySet()) {
            Row catRow = sheet.createRow(rowIndex++);
            Cell catCell = catRow.createCell(0);
            catCell.setCellValue(entry.getKey());
            catCell.setCellStyle(categoryStyle);
            sheet.addMergedRegion(new org.apache.poi.ss.util.CellRangeAddress(rowIndex - 1, rowIndex - 1, 0, headers.size() - 1));

            int[] subTotal = new int[headers.size()];

            for (List<String> rowData : entry.getValue()) {
                Row row = sheet.createRow(rowIndex++);
                for (int i = 0; i < rowData.size(); i++) {
                    Cell dataCell = row.createCell(i);
                    dataCell.setCellValue(rowData.get(i));
                    dataCell.setCellStyle(borderStyle);
                    try {
                        subTotal[i] += Integer.parseInt(rowData.get(i));
                    } catch (Exception ignored) {}
                }
            }

            Row subRow = sheet.createRow(rowIndex++);
            Cell subCell = subRow.createCell(1);
            subCell.setCellValue("SUB TOTAL");
            subCell.setCellStyle(boldStyle);
            for (int i = 2; i < subTotal.length; i++) {
                Cell totalCell = subRow.createCell(i);
                totalCell.setCellValue(subTotal[i]);
                totalCell.setCellStyle(boldStyle);
            }
        }

        for (int i = 0; i < headers.size(); i++) {
            sheet.autoSizeColumn(i);
        }

        FileOutputStream out = new FileOutputStream(EXCEL_FILE);
        workbook.write(out);
        workbook.close();
        out.close();
    }

    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = ((XSSFWorkbook) workbook).createFont();
        font.setBold(true);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle createBorderedStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle createBoldStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = ((XSSFWorkbook) workbook).createFont();
        font.setBold(true);
        style.setFont(font);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle createCategoryStyle(Workbook workbook) {
        CellStyle style = createBoldStyle(workbook);
        style.setFillForegroundColor(IndexedColors.DARK_RED.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        return style;
    }
}
