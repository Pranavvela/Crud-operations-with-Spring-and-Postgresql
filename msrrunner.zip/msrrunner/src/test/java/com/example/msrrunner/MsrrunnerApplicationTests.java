package com.example.msrrunner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsrrunnerApplicationTests {

	@Test
	void contextLoads() {
	}

}
