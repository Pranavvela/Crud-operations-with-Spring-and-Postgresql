package com.example.msrrunner.repository;

import com.example.msrrunner.model.ApplicationDbDetail;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ApplicationDbDetailsRepository {
    public List<ApplicationDbDetail> findAll() {
        List<ApplicationDbDetail> list = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(
                "jdbc:postgresql://192.168.1.6:5433/msr", "postgres", "trust");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM application_db_details")) {

            while (rs.next()) {
                ApplicationDbDetail detail = new ApplicationDbDetail();
                detail.setmsrslno(rs.getInt("msrslno"));
                detail.setdbServerIp(rs.getString("db_server_ip"));
                detail.setdbPort(rs.getString("db_port"));
                detail.setdbName(rs.getString("db_name"));
                detail.setdbUsername(rs.getString("db_username"));
                detail.setmsrstatename(rs.getString("msrstatename"));
                detail.setmsrstate_category(rs.getString("msrstate_category"));
                detail.setmsrstate_subcategory(rs.getString("msrstate_subcategory"));
                list.add(detail);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}