package com.example.msrrunner;

import com.example.msrrunner.model.ApplicationDbDetail;
import com.example.msrrunner.service.ReportService;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MsrrunnerApplication {
    public static void main(String[] args) {

        List<ApplicationDbDetail> dbDetails = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(
                "jdbc:postgresql://192.168.1.6:5433/msr", "postgres", "trust");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM application_db_details")) {

            while (rs.next()) {
                ApplicationDbDetail detail = new ApplicationDbDetail();
                detail.setmsrslno(rs.getInt("msrslno"));
                detail.setdbServerIp(rs.getString("db_server_ip"));
                detail.setdbPort(rs.getString("db_port"));
                detail.setdbName(rs.getString("db_name"));
                detail.setdbUsername(rs.getString("db_username"));
                detail.setmsrstatename(rs.getString("msrstatename"));
                detail.setmsrstate_category(rs.getString("msrstate_category"));
                detail.setmsrstate_subcategory(rs.getString("msrstate_subcategory"));
                dbDetails.add(detail);
            }

            new ReportService().process(dbDetails);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}